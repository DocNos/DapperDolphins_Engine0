#ifndef __VMML__MATRIX_COMPARE_PERF_TEST__HPP__
#define __VMML__MATRIX_COMPARE_PERF_TEST__HPP__

#include "performance_test.hpp"

namespace vmml
{

class matrix_compare_perf_test : public performance_test
{
public:
    virtual void run();

protected:

}; // class matrix_compare_perf_test

} // namespace vmml

#endif


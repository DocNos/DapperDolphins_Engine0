#!/bin/sh 

g++ stringtests.cpp -o stringstests -I../include

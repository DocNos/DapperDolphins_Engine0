#include "jacobi_test.hpp"

namespace vmml
{

bool
jacobi_test::run()
{
    bool ok;
    


    return ok;
}

} // namespace vmml

